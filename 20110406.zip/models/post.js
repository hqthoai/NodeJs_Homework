
const posts = [

]

module.exports = posts;